-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `mapping_takaoka_press` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `mapping_takaoka_press`;

CREATE TABLE `chokus` (
  `code` varchar(1) NOT NULL,
  `name` varchar(16) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`code`),
  UNIQUE KEY `chokus_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `chokus`;
INSERT INTO `chokus` (`code`, `name`, `status`, `created_at`, `updated_at`) VALUES
('B',	'黒直',	0,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('W',	'白直',	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('Y',	'黄直',	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54');

CREATE TABLE `combinations` (
  `line_code` varchar(16) NOT NULL,
  `vehicle_code` varchar(16) NOT NULL,
  `pt_pn` varchar(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`line_code`,`vehicle_code`,`pt_pn`),
  KEY `combinations_vehicle_code_foreign` (`vehicle_code`),
  KEY `combinations_pt_pn_foreign` (`pt_pn`),
  CONSTRAINT `combinations_line_code_foreign` FOREIGN KEY (`line_code`) REFERENCES `lines` (`code`) ON UPDATE CASCADE,
  CONSTRAINT `combinations_pt_pn_foreign` FOREIGN KEY (`pt_pn`) REFERENCES `part_types` (`pn`) ON UPDATE CASCADE,
  CONSTRAINT `combinations_vehicle_code_foreign` FOREIGN KEY (`vehicle_code`) REFERENCES `vehicles` (`code`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `combinations`;
INSERT INTO `combinations` (`line_code`, `vehicle_code`, `pt_pn`, `created_at`, `updated_at`) VALUES
('10B',	'660L',	'4444444444',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('22A',	'660L',	'4444444444',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('6A',	'660L',	'4444444444',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('ATR18',	'030A',	'3333333333',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('ATR18',	'410A',	'2222222222',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('ATR18',	'520A',	'1111111111',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('ATR18',	'660L',	'4444444444',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('ATR18',	'745L',	'3333333333',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('ATR18',	'963A',	'5381112B70',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('ATR18',	'963A',	'5381212B70',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54');

CREATE TABLE `failures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(10) unsigned NOT NULL,
  `ir_id` int(10) unsigned NOT NULL,
  `figure_id` int(10) unsigned DEFAULT NULL,
  `x1` int(10) unsigned NOT NULL DEFAULT '0',
  `y1` int(10) unsigned NOT NULL DEFAULT '0',
  `x2` int(10) unsigned NOT NULL DEFAULT '0',
  `y2` int(10) unsigned NOT NULL DEFAULT '0',
  `f_qty` int(10) unsigned NOT NULL DEFAULT '0',
  `m_qty` int(10) unsigned DEFAULT NULL,
  `responsible_for` tinyint(3) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `failures_type_id_foreign` (`type_id`),
  KEY `failures_ir_id_foreign` (`ir_id`),
  KEY `failures_figure_id_foreign` (`figure_id`),
  CONSTRAINT `failures_figure_id_foreign` FOREIGN KEY (`figure_id`) REFERENCES `figures` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `failures_ir_id_foreign` FOREIGN KEY (`ir_id`) REFERENCES `inspection_results` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `failures_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `failure_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `failures`;
INSERT INTO `failures` (`id`, `type_id`, `ir_id`, `figure_id`, `x1`, `y1`, `x2`, `y2`, `f_qty`, `m_qty`, `responsible_for`, `created_at`, `updated_at`) VALUES
(1,	1,	1,	1,	101,	101,	201,	201,	3,	2,	1,	'2017-02-20 13:29:58',	'2017-02-21 00:32:26'),
(2,	2,	1,	1,	102,	102,	202,	202,	3,	1,	2,	'2017-02-20 13:29:58',	'2017-02-21 00:32:26'),
(3,	3,	1,	1,	103,	103,	203,	203,	3,	0,	3,	'2017-02-20 13:29:58',	'2017-02-21 00:32:26'),
(4,	1,	2,	1,	101,	101,	201,	201,	3,	NULL,	0,	'2017-02-20 13:42:06',	'2017-02-20 13:42:06'),
(5,	2,	2,	1,	102,	102,	202,	202,	2,	NULL,	1,	'2017-02-20 13:42:06',	'2017-02-20 13:42:06'),
(6,	3,	2,	1,	103,	103,	203,	203,	1,	NULL,	2,	'2017-02-20 13:42:06',	'2017-02-20 13:42:06'),
(7,	1,	3,	1,	101,	101,	201,	201,	3,	NULL,	0,	'2017-02-20 13:42:26',	'2017-02-20 13:42:26'),
(8,	2,	3,	1,	102,	102,	202,	202,	2,	NULL,	1,	'2017-02-20 13:42:26',	'2017-02-20 13:42:26'),
(9,	3,	3,	1,	103,	103,	203,	203,	1,	NULL,	2,	'2017-02-20 13:42:26',	'2017-02-20 13:42:26'),
(12,	1,	1,	1,	100,	100,	200,	200,	3,	2,	1,	'2017-02-21 00:32:26',	'2017-02-21 00:32:26');

CREATE TABLE `failure_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `label` int(10) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failure_types_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `failure_types`;
INSERT INTO `failure_types` (`id`, `name`, `label`, `status`, `created_at`, `updated_at`) VALUES
(1,	'凸',	1,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(2,	'凹',	2,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(3,	'油歪凸',	3,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(4,	'油歪凹',	4,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(5,	'型当凸',	5,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(6,	'型当凹',	6,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(7,	'カジリ',	7,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(8,	'カップ歪',	8,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(9,	'スクラ押',	9,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(10,	'パウダリ',	10,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(11,	'変形',	11,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(12,	'バリ',	12,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(13,	'キズ',	13,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(14,	'マクレ',	14,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(15,	'その他',	99,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54');

CREATE TABLE `figures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pt_pn` varchar(10) NOT NULL,
  `path` varchar(255) NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `figures_pt_pn_foreign` (`pt_pn`),
  CONSTRAINT `figures_pt_pn_foreign` FOREIGN KEY (`pt_pn`) REFERENCES `part_types` (`pn`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `figures`;
INSERT INTO `figures` (`id`, `pt_pn`, `path`, `status`, `created_at`, `updated_at`) VALUES
(1,	'5381212B70',	'/img/figures/5381212B70-123456789.png',	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(2,	'5381212B70',	'/img/figures/5381212B70-123456788.png',	0,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(3,	'5381112B70',	'/img/figures/5381112B70-123456789.png',	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54');

CREATE TABLE `inspection_results` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `QRcode` varchar(134) NOT NULL,
  `line_code` varchar(16) NOT NULL,
  `vehicle_code` varchar(16) NOT NULL,
  `pt_pn` varchar(10) NOT NULL,
  `figure_id` int(10) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `f_keep` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `m_keep` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `discarded` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `inspected_choku` varchar(8) NOT NULL,
  `modificated_choku` varchar(8) DEFAULT NULL,
  `updated_choku` varchar(8) DEFAULT NULL,
  `inspected_by` varchar(8) NOT NULL,
  `modificated_by` varchar(8) DEFAULT NULL,
  `updated_by` varchar(8) DEFAULT NULL,
  `palet_num` int(10) unsigned NOT NULL,
  `palet_max` int(10) unsigned NOT NULL,
  `ft_ids` varchar(512) DEFAULT NULL,
  `f_comment` varchar(255) DEFAULT NULL,
  `m_comment` varchar(255) DEFAULT NULL,
  `processed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `inspected_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modificated_at` timestamp NULL DEFAULT NULL,
  `exported_at` timestamp NULL DEFAULT NULL,
  `latest` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `control_num` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_results_qrcode_unique` (`QRcode`),
  UNIQUE KEY `inspection_results_inspected_choku_control_num_unique` (`inspected_choku`,`control_num`),
  KEY `inspection_results_line_code_foreign` (`line_code`),
  KEY `inspection_results_vehicle_code_foreign` (`vehicle_code`),
  KEY `inspection_results_pt_pn_foreign` (`pt_pn`),
  KEY `inspection_results_figure_id_foreign` (`figure_id`),
  CONSTRAINT `inspection_results_figure_id_foreign` FOREIGN KEY (`figure_id`) REFERENCES `figures` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `inspection_results_line_code_foreign` FOREIGN KEY (`line_code`) REFERENCES `lines` (`code`) ON UPDATE CASCADE,
  CONSTRAINT `inspection_results_pt_pn_foreign` FOREIGN KEY (`pt_pn`) REFERENCES `part_types` (`pn`) ON UPDATE CASCADE,
  CONSTRAINT `inspection_results_vehicle_code_foreign` FOREIGN KEY (`vehicle_code`) REFERENCES `vehicles` (`code`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `inspection_results`;
INSERT INTO `inspection_results` (`id`, `QRcode`, `line_code`, `vehicle_code`, `pt_pn`, `figure_id`, `status`, `f_keep`, `m_keep`, `discarded`, `inspected_choku`, `modificated_choku`, `updated_choku`, `inspected_by`, `modificated_by`, `updated_by`, `palet_num`, `palet_max`, `ft_ids`, `f_comment`, `m_comment`, `processed_at`, `inspected_at`, `modificated_at`, `exported_at`, `latest`, `control_num`, `created_at`, `updated_at`) VALUES
(1,	'PLK02JT   KJT1TP 01H6T10  5381212B7000300104 00180HOB2-E-9          201702101916552017020917165800100200000000214487012017020917180600',	'ATR18',	'963A',	'5381212B70',	1,	1,	0,	1,	1,	'W',	'W',	NULL,	'山田 太郎',	'山田 太郎',	NULL,	25,	30,	'a:15:{i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:4;i:5;i:5;i:6;i:6;i:7;i:7;i:8;i:8;i:9;i:9;i:10;i:10;i:11;i:11;i:12;i:12;i:13;i:13;i:14;i:14;i:15;}',	'255文字までのコメント',	'255文字までのコメント',	'2017-02-21 00:32:26',	'2017-02-20 13:29:57',	'2017-02-21 00:32:25',	NULL,	1,	2,	'2017-02-20 13:29:57',	'2017-02-21 00:32:25'),
(2,	'PLK02JT   KJT1TP 01H6T10  5381212B7000300104 00180HOB2-E-9          201702101916552017020917165900100200000000214487012017020917180600',	'ATR18',	'963A',	'5381212B70',	1,	1,	0,	1,	0,	'W',	NULL,	NULL,	'山田 太郎',	NULL,	NULL,	25,	30,	'a:15:{i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:4;i:5;i:5;i:6;i:6;i:7;i:7;i:8;i:8;i:9;i:9;i:10;i:10;i:11;i:11;i:12;i:12;i:13;i:13;i:14;i:14;i:15;}',	'255文字までのコメント',	NULL,	'2017-02-09 08:16:59',	'2017-02-20 13:42:06',	NULL,	NULL,	1,	1,	'2017-02-20 13:42:06',	'2017-02-20 13:42:06'),
(3,	'PLK02JT   KJT1TP 01H6T10  5381212B7000300104 00180HOB2-E-9          201702101916552017020917170100100200000000214487012017020917180600',	'ATR18',	'963A',	'5381212B70',	1,	1,	0,	1,	0,	'Y',	NULL,	NULL,	'山田 太郎',	NULL,	NULL,	25,	30,	'a:15:{i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:4;i:5;i:5;i:6;i:6;i:7;i:7;i:8;i:8;i:9;i:9;i:10;i:10;i:11;i:11;i:12;i:12;i:13;i:13;i:14;i:14;i:15;}',	'255文字までのコメント',	NULL,	'2017-02-09 08:17:01',	'2017-02-20 13:42:26',	NULL,	NULL,	1,	1,	'2017-02-20 13:42:26',	'2017-02-20 13:42:26');

CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_reserved_at_index` (`queue`,`reserved`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `jobs`;

CREATE TABLE `lines` (
  `code` varchar(16) NOT NULL,
  `code_inQR` varchar(16) NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '1',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`code`),
  UNIQUE KEY `lines_code_inqr_unique` (`code_inQR`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `lines`;
INSERT INTO `lines` (`code`, `code_inQR`, `sort`, `status`, `created_at`, `updated_at`) VALUES
('10B',	'E7T',	4,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('22A',	'I2A',	3,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('6A',	'E6T',	2,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('ATR18',	'H6T',	1,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54');

CREATE TABLE `migrations` (
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `migrations`;
INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table',	1),
('2014_10_12_100000_create_password_resets_table',	1),
('2016_06_21_094134_create_jobs_table',	1),
('2016_09_01_000000_create_base_tables_for_press',	1),
('2016_09_01_000001_create_result_tables_for_press',	1);

CREATE TABLE `part_types` (
  `pn` varchar(10) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `en` varchar(32) DEFAULT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pn`),
  UNIQUE KEY `part_types_name_unique` (`name`),
  UNIQUE KEY `part_types_en_unique` (`en`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `part_types`;
INSERT INTO `part_types` (`pn`, `name`, `en`, `sort`, `created_at`, `updated_at`) VALUES
('1111111111',	'ダミー1',	'dummy1',	3,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('2222222222',	'ダミー2',	'dummy2',	4,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('3333333333',	'ダミー3',	'dummy3',	5,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('4444444444',	'ダミー4',	'dummy4',	6,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('5381112B70',	'パネル フロントフェンダR',	'panel frontFenderR',	2,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('5381212B70',	'パネル フロントフェンダL',	'panel frontFenderL',	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54');

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `password_resets`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `password` varchar(60) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `users`;

CREATE TABLE `vehicles` (
  `code` varchar(16) NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '1',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `vehicles`;
INSERT INTO `vehicles` (`code`, `sort`, `status`, `created_at`, `updated_at`) VALUES
('030A',	4,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('410A',	3,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('520A',	2,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('660L',	6,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('745L',	5,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
('963A',	1,	1,	'2017-02-20 13:29:54',	'2017-02-20 13:29:54');

CREATE TABLE `workers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `yomi` varchar(16) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `choku_code` varchar(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workers_choku_code_foreign` (`choku_code`),
  CONSTRAINT `workers_choku_code_foreign` FOREIGN KEY (`choku_code`) REFERENCES `chokus` (`code`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

TRUNCATE `workers`;
INSERT INTO `workers` (`id`, `name`, `yomi`, `sort`, `status`, `choku_code`, `created_at`, `updated_at`) VALUES
(1,	'田村 良二',	'タムラリョウジ',	1,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(2,	'高木 洋一',	'タカギヨウイチ',	2,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(3,	'山本 佳祐',	'ヤマシタケイスケ',	3,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(4,	'森下 和哉',	'モリシタカズヤ',	4,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(5,	'浅田 英幸',	'アサダヒデユキ',	5,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(6,	'青木 匠',	'アオキタクミ',	6,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(7,	'高須 信吾',	'タカスシンゴ',	7,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(8,	'矢澤 鉱一',	'ヤザワコウイチ',	8,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(9,	'大園 博美',	'オオゾノヒロミ',	9,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(10,	'川畑 英義',	'カワバタヒデヨシ',	10,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(11,	'金谷 達弘',	'カナヤタツヒロ',	11,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(12,	'阿部 哲士',	'アベテツシ',	12,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(13,	'黒崎 将平',	'クロサキ ショウヘイ',	13,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(14,	'小川 晟央',	'オガワマサオ',	14,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(15,	'古井 康真',	'フルイヤスシ',	15,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(16,	'大塚 絢貴',	'オオツカアヤタカ',	16,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(17,	'濱田 政雄',	'ハマダマサオ',	17,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(18,	'岡本 崇弘',	'オカモトタカヒロ',	18,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(19,	'戸上 憲一',	'トガミケンイチ',	19,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(20,	'西嶋 慎吾',	'ニシジマシンゴ',	20,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(21,	'橋本 高浩',	'ハシモトタカヒロ',	21,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(22,	'西川 佳孝',	'ニシカワヨシタカ',	22,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(23,	'嶋津 直樹',	'シマズナオキ',	23,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(24,	'梅田 雄司',	'ウメダユウジ',	24,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(25,	'山尾 祐介',	'ヤマオユウスケ',	25,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(26,	'白波瀬 忍',	'シロナミセシノブ',	26,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(27,	'中田 将吾',	'ナカダショウゴ',	27,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(28,	'井坂 光雄',	'イサカミツオ',	28,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(29,	'大寺 真悟',	'オオデラシンゴ',	29,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(30,	'大谷 直人',	'オオタニナオト',	30,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(31,	'児嶋 誠',	'コジママコト',	31,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(32,	'吉武 伸浩',	'ヨシタケノブヒロ',	32,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(33,	'加藤 徹',	'カトウトオル',	33,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(34,	'瀬川 瑛志',	'セガワエイシ',	34,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(35,	'宗像 徹郎',	'ムナカタテツロウ',	35,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(36,	'田村 豊',	'タムラユタカ',	36,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(37,	'伊藤 伸一',	'イトウシンイチ',	37,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(38,	'中本 直樹',	'ナカモトナオキ',	38,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(39,	'尾前 裕也',	'オマエユウヤ',	39,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(40,	'蘭 龍二',	'ランリュウジ',	40,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(41,	'渡辺 孝司',	'ワタナベコウジ',	41,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(42,	'大石 峰志',	'オオイシタカシ',	42,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(43,	'土居 豊',	'ツチイ ユタカ',	43,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(44,	'龍田 憲太',	'タツタケンタ',	44,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(45,	'小林 徹也',	'コバヤシテツヤ',	45,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(46,	'渡久地 政通',	'トグチマサトシ',	46,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(47,	'浅野 秀明',	'アサノヒデアキ',	47,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(48,	'蜂谷 拓也',	'ハチヤタクヤ',	48,	1,	'W',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(49,	'瀬畑 長正',	'セバタナガマサ',	49,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(50,	'長畑 学',	'ナガハタマナブ',	50,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(51,	'吉川 慎吾',	'ヨシカワ シンゴ',	51,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(52,	'東野 博',	'ヒガシノヒロシ',	52,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(53,	'藤川 徹',	'フジカワトオル',	53,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54'),
(54,	'萩野 隆',	'ハギノタカシ',	54,	1,	'Y',	'2017-02-20 13:29:54',	'2017-02-20 13:29:54');

-- 2017-02-21 01:58:10
